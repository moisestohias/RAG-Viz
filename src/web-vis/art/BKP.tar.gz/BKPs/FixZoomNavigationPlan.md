# Plan for Enhancing Visualization Navigation

## Objective
Implement enhanced navigation functionality for the 3D embedding visualization:
1. Allow significantly more zoom levels
2. Enable Ctrl+drag for panning across different regions

## Current State Analysis
- Current zoom extent is limited to [0.3, 10] in `app.js`
- Current drag functionality rotates the 3D coordinates (ax, ay)
- No panning functionality exists

## Implementation Steps

### Step 1: Modify Zoom Scale Extent
- File: `static/js/app.js`
- Change current zoom scale from [0.3, 10] to a wider range like [0.1, 50]
- This will allow zooming much further in and out

### Step 2: Implement Ctrl+Drag Panning
- File: `static/js/app.js`
- Add panning capability that moves the coordinate system when Ctrl key is held
- Track initial mouse position for panning calculation
- Integrate panning with existing rotation functionality

### Step 3: Update View Transformation Logic
- Modify the projection function to account for panning offset
- Introduce variables to track pan offsets (panX, panY)
- Adjust the rendering to incorporate the pan offsets

### Step 4: Update UI Instructions
- File: `templates/opus_45_index.html`
- Update the instruction text to reflect new navigation methods
- Show both drag-to-rotate and Ctrl+drag-to-pan functionality

## Technical Implementation Details

### For Zoom:
- Modify the `.scaleExtent()` in the zoom behavior to allow a larger range
- Current code: `.scaleExtent([0.3, 10])`
- New code: `.scaleExtent([0.1, 50])` or whatever appropriate range

### For Panning:
- Need to detect when Ctrl key is pressed during drag event
- When Ctrl is pressed, update panX and panY values instead of ax and ay
- Modify the project() function to incorporate pan offsets

### Code Modifications:

#### static/js/app.js
```javascript
// Add pan variables
let pts = [], ax = 0.4, ay = -0.5, scale = 1, baseSize = 4;
let panX = 0, panY = 0;

// Modify project function to incorporate pan
const project = p => {
    // existing rotation calculations
    const cy = Math.cos(ay), sy = Math.sin(ay), cx = Math.cos(ax), sx = Math.sin(ax);
    const x1 = p.x * cy - p.z * sy, z1 = p.x * sy + p.z * cy;
    const y1 = p.y * cx - z1 * sx, z2 = p.y * sx + z1 * cx;
    const s = (180 * scale) / (4 + z2);
    return { 
        px: x1 * s + W / 2 + panX,  // Add panX offset
        py: y1 * s + H / 2 + panY,  // Add panY offset
        pz: z2, 
        name: p.name, 
        idx: p.idx 
    };
};

// Update drag behavior to handle Ctrl for panning
svg.call(d3.drag()
    .on("start", function() { /* handle drag start */ })
    .on("drag", function() { 
        if (d3.event.sourceEvent.ctrlKey) { // Pan when Ctrl is pressed
            panX += d3.event.dx;
            panY += d3.event.dy;
        } else { // Rotate when Ctrl is not pressed
            ay += d3.event.dx * 0.008;
            ax += d3.event.dy * 0.008;
        }
        render(); 
    }));

// Update zoom behavior with extended range
svg.call(d3.zoom()
    .scaleExtent([0.1, 50])  // Extended zoom range
    .filter(e => e.type === 'wheel' || e.type === 'dblclick')
    .on("zoom", e => { scale = e.transform.k; render(); }));
```

#### templates/opus_45_index.html
- Update the navigation instructions in the header to reflect both rotation and panning
- Change: "drag to rotate • scroll to zoom"
- To: "drag to rotate • Ctrl+drag to pan • scroll to zoom"

## Testing Plan
1. Verify that the zoom can go significantly further in and out
2. Ensure Ctrl+drag enables panning functionality
3. Test that regular dragging still rotates the visualization
4. Test that both functionalities work together without interference
5. Verify tooltip positioning remains accurate during panning