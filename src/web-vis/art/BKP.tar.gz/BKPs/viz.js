// static/viz.js
const container = document.getElementById('viz');
const tooltip = document.getElementById('tooltip');
let points = [];
let angleX = 0.3, angleY = 0.5, isDragging = false, lastMouse = {x: 0, y: 0};

const width = container.clientWidth;
const height = container.clientHeight;
const scale = Math.min(width, height) * 0.35;

const svg = d3.select('#viz').append('svg')
    .attr('width', width).attr('height', height)
    .style('background', 'radial-gradient(circle, #1a1a2e 0%, #0f0f1a 100%)');

const g = svg.append('g').attr('transform', `translate(${width/2}, ${height/2})`);

const colorScale = d3.scaleOrdinal(d3.schemeTableau10);

function project3D(x, y, z) {
    const cosX = Math.cos(angleX), sinX = Math.sin(angleX);
    const cosY = Math.cos(angleY), sinY = Math.sin(angleY);
    const y1 = y * cosX - z * sinX;
    const z1 = y * sinX + z * cosX;
    const x1 = x * cosY + z1 * sinY;
    const z2 = -x * sinY + z1 * cosY;
    const perspective = 1 + z2 * 0.3;
    return { x: x1 * scale / perspective, y: y1 * scale / perspective, z: z2 };
}

function render() {
    const projected = points.map((p, i) => ({
        ...p, ...project3D(p.x, p.y, p.z), idx: i
    })).sort((a, b) => a.z - b.z);

    const nodes = g.selectAll('.node').data(projected, d => d.name);
    
    nodes.enter().append('circle')
        .attr('class', 'node')
        .attr('r', 0)
        .attr('fill', d => colorScale(d.idx))
        .on('mouseenter', (e, d) => {
            tooltip.style.opacity = 1;
            tooltip.textContent = d.name;
        })
        .on('mousemove', e => {
            tooltip.style.left = e.pageX + 12 + 'px';
            tooltip.style.top = e.pageY - 12 + 'px';
        })
        .on('mouseleave', () => tooltip.style.opacity = 0)
        .merge(nodes)
        .transition().duration(300)
        .attr('cx', d => d.x)
        .attr('cy', d => d.y)
        .attr('r', d => 6 + (d.z + 1) * 4)
        .attr('opacity', d => 0.5 + (d.z + 1) * 0.25);
    
    nodes.exit().transition().duration(200).attr('r', 0).remove();
}

svg.on('mousedown', e => { isDragging = true; lastMouse = {x: e.clientX, y: e.clientY}; })
   .on('mouseup', () => isDragging = false)
   .on('mouseleave', () => isDragging = false)
   .on('mousemove', e => {
       if (!isDragging) return;
       angleY += (e.clientX - lastMouse.x) * 0.01;
       angleX += (e.clientY - lastMouse.y) * 0.01;
       lastMouse = {x: e.clientX, y: e.clientY};
       render();
   });

function updateVisualization(data) {
    points = JSON.parse(data);
    render();
}

// Initial load
fetch('/api/umap').then(r => r.json()).then(data => { points = data; render(); });

// Auto-rotate
(function rotate() {
    if (!isDragging) { angleY += 0.002; render(); }
    requestAnimationFrame(rotate);
})();

window.updateVisualization = updateVisualization;
